# AI Resume Analyzer & Job Matching System

A full-stack web application that parses PDF resumes using NLP/BERT, scores them against job descriptions using semantic similarity, and surfaces a skills-gap analysis — all in real time.

![Python](https://img.shields.io/badge/Python-3.11-blue?logo=python)
![FastAPI](https://img.shields.io/badge/FastAPI-0.111-green?logo=fastapi)
![React](https://img.shields.io/badge/React-18-61dafb?logo=react)
![License](https://img.shields.io/badge/license-MIT-lightgrey)

---

## Demo

> Upload a PDF resume → paste a job description → get an instant match score, matched skills, and skill gap in seconds.

---

## Features

- **PDF Parsing** — extracts raw text from uploaded PDF resumes using `pdfplumber`
- **NLP Entity Extraction** — uses `spaCy` (NER) and a curated keyword list to identify technical skills, education, and experience
- **Semantic Similarity Scoring** — blends BERT sentence embeddings (`sentence-transformers`) with TF-IDF cosine similarity for robust matching
- **Skill Gap Analysis** — compares detected resume skills against job description requirements and highlights what's missing
- **Real-time React UI** — drag-and-drop upload, animated score ring, colour-coded skill pills, and instant feedback
- **FastAPI backend** — sub-second inference latency with async endpoints

---

## Architecture

```
frontend/          React + Vite SPA
  src/
    App.jsx
    components/
      UploadForm.jsx     drag-and-drop PDF upload + JD input
      ScoreDisplay.jsx   animated circular score ring
      SkillsPanel.jsx    matched / missing skill pills

backend/           Python FastAPI service
  main.py          API routes (/analyze, /match-text)
  resume_parser.py PDF extraction, spaCy NER, skill detection
  job_matcher.py   BERT + TF-IDF blended similarity scoring
  Dockerfile
  requirements.txt
```

---

## Tech Stack

| Layer | Tech |
|---|---|
| Frontend | React 18, Vite |
| Backend | Python 3.11, FastAPI, Uvicorn |
| NLP / Parsing | spaCy, pdfplumber |
| Embeddings | sentence-transformers (all-MiniLM-L6-v2) |
| Similarity | TF-IDF (scikit-learn) + cosine similarity |
| Containerisation | Docker |

---

## Getting Started

### Prerequisites

- Python 3.10+
- Node.js 18+

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate       # Windows: venv\Scripts\activate
pip install -r requirements.txt
python -m spacy download en_core_web_sm
uvicorn main:app --reload
```

API will be live at `http://localhost:8000`. Interactive docs at `http://localhost:8000/docs`.

### Frontend

```bash
cd frontend
npm install
npm run dev
```

App will open at `http://localhost:3000`.

### Docker (backend only)

```bash
cd backend
docker build -t resume-analyzer-api .
docker run -p 8000:8000 resume-analyzer-api
```

---

## API Reference

### `POST /analyze`

Upload a PDF resume and optionally a job description.

**Form fields:**
- `file` — PDF file
- `job_description` — plain text (optional)

**Response:**
```json
{
  "skills": ["python", "fastapi", "docker", "bert"],
  "experience_years": 2,
  "education": "B.Tech — Computer Science & Engineering",
  "match_score": 78.4,
  "matched_skills": ["python", "fastapi"],
  "missing_skills": ["kubernetes", "spark"],
  "recommendation": "Strong match — this resume aligns well with the job description."
}
```

### `POST /match-text`

Match raw text strings without file upload.

```json
{
  "resume_text": "...",
  "job_description": "..."
}
```

---

## How Scoring Works

1. **BERT Semantic Similarity (70%)** — sentence-transformers encodes both texts into dense embeddings and computes cosine similarity
2. **TF-IDF Similarity (30%)** — keyword overlap weighted by term frequency/inverse document frequency
3. **Skill Gap** — exact keyword matching against a curated list of 60+ tech skills in both documents

---

## Project Structure

```
ai-resume-analyzer/
├── backend/
│   ├── main.py
│   ├── resume_parser.py
│   ├── job_matcher.py
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── App.jsx
│   │   ├── App.css
│   │   ├── main.jsx
│   │   └── components/
│   │       ├── UploadForm.jsx
│   │       ├── ScoreDisplay.jsx
│   │       └── SkillsPanel.jsx
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
├── .gitignore
└── README.md
```

---

## License

MIT
