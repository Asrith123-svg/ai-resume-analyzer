import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer, util

SKILL_KEYWORDS = [
    "python", "javascript", "typescript", "java", "c++", "c#", "go", "rust",
    "react", "vue", "angular", "next.js", "node.js", "fastapi", "flask", "django",
    "sql", "postgresql", "mysql", "mongodb", "redis", "elasticsearch",
    "docker", "kubernetes", "aws", "gcp", "azure", "terraform", "linux",
    "git", "ci/cd", "jenkins", "github actions",
    "machine learning", "deep learning", "nlp", "pytorch", "tensorflow",
    "scikit-learn", "pandas", "numpy", "bert", "llm", "transformers",
    "langchain", "faiss", "rag", "lora", "qlora", "peft",
    "rest api", "graphql", "grpc", "microservices",
    "spark", "kafka", "airflow", "dbt", "etl",
    "prometheus", "grafana", "elk", "datadog",
]


class JobMatcher:
    def __init__(self):
        self.model = SentenceTransformer("all-MiniLM-L6-v2")
        self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))

    def match(self, resume_text: str, job_description: str) -> dict:
        # 1. Semantic similarity (BERT)
        resume_emb = self.model.encode(resume_text[:2000], convert_to_tensor=True)
        jd_emb = self.model.encode(job_description[:2000], convert_to_tensor=True)
        semantic_score = float(util.cos_sim(resume_emb, jd_emb)[0][0])

        # 2. TF-IDF similarity
        try:
            tfidf_matrix = self.vectorizer.fit_transform([resume_text, job_description])
            tfidf_score = float(cosine_similarity(tfidf_matrix[0], tfidf_matrix[1])[0][0])
        except Exception:
            tfidf_score = 0.0

        # Blend: 70% semantic, 30% TF-IDF
        final_score = 0.7 * semantic_score + 0.3 * tfidf_score

        # 3. Skill gap analysis
        resume_skills = self._extract_skills(resume_text)
        jd_skills = self._extract_skills(job_description)

        matched = sorted(set(resume_skills) & set(jd_skills))
        missing = sorted(set(jd_skills) - set(resume_skills))

        return {
            "match_score": min(final_score, 1.0),
            "matched_skills": matched,
            "missing_skills": missing,
            "semantic_score": round(semantic_score, 4),
            "tfidf_score": round(tfidf_score, 4),
        }

    def _extract_skills(self, text: str) -> list[str]:
        text_lower = text.lower()
        return [skill for skill in SKILL_KEYWORDS if skill in text_lower]
