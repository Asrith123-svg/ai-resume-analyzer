from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import uvicorn

from resume_parser import ResumeParser
from job_matcher import JobMatcher

app = FastAPI(title="AI Resume Analyzer API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

parser = ResumeParser()
matcher = JobMatcher()


class MatchRequest(BaseModel):
    resume_text: str
    job_description: str


class AnalysisResponse(BaseModel):
    skills: list[str]
    experience_years: Optional[int]
    education: Optional[str]
    match_score: float
    matched_skills: list[str]
    missing_skills: list[str]
    recommendation: str


@app.get("/")
def root():
    return {"message": "AI Resume Analyzer API is running"}


@app.post("/analyze", response_model=AnalysisResponse)
async def analyze_resume(
    file: UploadFile = File(...),
    job_description: str = ""
):
    if not file.filename.endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")

    content = await file.read()
    resume_text = parser.extract_text_from_pdf(content)

    parsed = parser.parse(resume_text)
    match_result = matcher.match(resume_text, job_description) if job_description else {
        "match_score": 0.0,
        "matched_skills": [],
        "missing_skills": [],
    }

    score = match_result["match_score"]
    if score >= 0.75:
        recommendation = "Strong match — this resume aligns well with the job description."
    elif score >= 0.5:
        recommendation = "Moderate match — consider highlighting the missing skills or gaining experience in them."
    else:
        recommendation = "Weak match — significant skill gaps exist. Focus on the missing skills listed below."

    return AnalysisResponse(
        skills=parsed["skills"],
        experience_years=parsed["experience_years"],
        education=parsed["education"],
        match_score=round(score * 100, 1),
        matched_skills=match_result["matched_skills"],
        missing_skills=match_result["missing_skills"],
        recommendation=recommendation,
    )


@app.post("/match-text")
def match_text(request: MatchRequest):
    result = matcher.match(request.resume_text, request.job_description)
    return {
        "match_score": round(result["match_score"] * 100, 1),
        "matched_skills": result["matched_skills"],
        "missing_skills": result["missing_skills"],
    }


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
