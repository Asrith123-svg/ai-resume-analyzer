import io
import re
from typing import Optional

import spacy
import pdfplumber
from sentence_transformers import SentenceTransformer

# Common tech skills for extraction
SKILL_KEYWORDS = [
    "python", "javascript", "typescript", "java", "c++", "c#", "go", "rust",
    "react", "vue", "angular", "next.js", "node.js", "fastapi", "flask", "django",
    "sql", "postgresql", "mysql", "mongodb", "redis", "elasticsearch",
    "docker", "kubernetes", "aws", "gcp", "azure", "terraform", "linux",
    "git", "ci/cd", "jenkins", "github actions",
    "machine learning", "deep learning", "nlp", "pytorch", "tensorflow",
    "scikit-learn", "pandas", "numpy", "bert", "llm", "transformers",
    "langchain", "faiss", "rag", "lora", "qlora", "peft",
    "rest api", "graphql", "grpc", "microservices",
    "spark", "kafka", "airflow", "dbt", "etl",
    "prometheus", "grafana", "elk", "datadog",
]

EDUCATION_KEYWORDS = ["b.tech", "m.tech", "bachelor", "master", "phd", "b.e", "m.e",
                       "b.sc", "m.sc", "mba", "computer science", "engineering"]


class ResumeParser:
    def __init__(self):
        try:
            self.nlp = spacy.load("en_core_web_sm")
        except OSError:
            import subprocess
            subprocess.run(["python", "-m", "spacy", "download", "en_core_web_sm"], check=True)
            self.nlp = spacy.load("en_core_web_sm")

        self.model = SentenceTransformer("all-MiniLM-L6-v2")

    def extract_text_from_pdf(self, pdf_bytes: bytes) -> str:
        text = ""
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            for page in pdf.pages:
                extracted = page.extract_text()
                if extracted:
                    text += extracted + "\n"
        return text.strip()

    def parse(self, text: str) -> dict:
        return {
            "skills": self._extract_skills(text),
            "experience_years": self._extract_experience_years(text),
            "education": self._extract_education(text),
        }

    def _extract_skills(self, text: str) -> list[str]:
        text_lower = text.lower()
        found = []
        for skill in SKILL_KEYWORDS:
            if skill in text_lower:
                found.append(skill)
        # Also use spaCy NER for any org/product names we might have missed
        doc = self.nlp(text[:5000])  # limit for speed
        for ent in doc.ents:
            if ent.label_ in ("ORG", "PRODUCT") and len(ent.text) > 2:
                candidate = ent.text.lower()
                if candidate not in found and not candidate.isdigit():
                    found.append(candidate)
        return sorted(set(found))

    def _extract_experience_years(self, text: str) -> Optional[int]:
        patterns = [
            r"(\d+)\+?\s+years?\s+of\s+experience",
            r"(\d+)\+?\s+years?\s+experience",
            r"experience\s+of\s+(\d+)\+?\s+years?",
        ]
        for pattern in patterns:
            match = re.search(pattern, text.lower())
            if match:
                return int(match.group(1))

        # Estimate from date ranges (e.g., 2021 – 2024)
        years = re.findall(r"\b(20\d{2})\b", text)
        if len(years) >= 2:
            years = [int(y) for y in years]
            span = max(years) - min(years)
            if 0 < span <= 20:
                return span
        return None

    def _extract_education(self, text: str) -> Optional[str]:
        lines = text.split("\n")
        for line in lines:
            line_lower = line.lower()
            if any(kw in line_lower for kw in EDUCATION_KEYWORDS):
                return line.strip()
        return None

    def get_embedding(self, text: str):
        return self.model.encode(text, convert_to_tensor=True)
