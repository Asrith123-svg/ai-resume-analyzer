import { useState } from "react";
import UploadForm from "./components/UploadForm";
import ScoreDisplay from "./components/ScoreDisplay";
import SkillsPanel from "./components/SkillsPanel";
import "./App.css";

export default function App() {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleAnalyze = async ({ file, jobDescription }) => {
    setLoading(true);
    setError("");
    setResult(null);

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("job_description", jobDescription);

      const res = await fetch("http://localhost:8000/analyze", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Analysis failed.");
      }

      const data = await res.json();
      setResult(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>AI Resume Analyzer</h1>
        <p className="subtitle">
          Upload your resume and a job description to get an instant match score
          and skill gap analysis.
        </p>
      </header>

      <main className="app-main">
        <UploadForm onSubmit={handleAnalyze} loading={loading} />

        {error && <div className="error-banner">{error}</div>}

        {result && (
          <div className="results">
            <ScoreDisplay
              score={result.match_score}
              recommendation={result.recommendation}
              experienceYears={result.experience_years}
              education={result.education}
            />
            <SkillsPanel
              skills={result.skills}
              matched={result.matched_skills}
              missing={result.missing_skills}
            />
          </div>
        )}
      </main>
    </div>
  );
}
