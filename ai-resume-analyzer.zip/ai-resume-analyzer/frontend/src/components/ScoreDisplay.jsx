export default function ScoreDisplay({ score, recommendation, experienceYears, education }) {
  const getColor = () => {
    if (score >= 75) return "#22c55e";
    if (score >= 50) return "#f59e0b";
    return "#ef4444";
  };

  const getLabel = () => {
    if (score >= 75) return "Strong Match";
    if (score >= 50) return "Moderate Match";
    return "Weak Match";
  };

  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="score-card">
      <h2>Match Score</h2>

      {/* Circular progress */}
      <div className="score-ring-wrapper">
        <svg width="140" height="140" viewBox="0 0 140 140">
          <circle cx="70" cy="70" r={radius} fill="none" stroke="#e5e7eb" strokeWidth="12" />
          <circle
            cx="70" cy="70" r={radius}
            fill="none"
            stroke={getColor()}
            strokeWidth="12"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            transform="rotate(-90 70 70)"
            style={{ transition: "stroke-dashoffset 0.8s ease" }}
          />
        </svg>
        <div className="score-label">
          <span className="score-number" style={{ color: getColor() }}>{score}%</span>
          <span className="score-text">{getLabel()}</span>
        </div>
      </div>

      <p className="recommendation">{recommendation}</p>

      <div className="meta-grid">
        {experienceYears !== null && experienceYears !== undefined && (
          <div className="meta-item">
            <span className="meta-label">Experience</span>
            <span className="meta-value">{experienceYears} yrs</span>
          </div>
        )}
        {education && (
          <div className="meta-item">
            <span className="meta-label">Education</span>
            <span className="meta-value">{education}</span>
          </div>
        )}
      </div>
    </div>
  );
}
