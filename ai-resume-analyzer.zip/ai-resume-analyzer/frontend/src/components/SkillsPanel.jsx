export default function SkillsPanel({ skills, matched, missing }) {
  return (
    <div className="skills-panel">
      {/* All detected skills */}
      <div className="skill-section">
        <h3>Detected Skills <span className="count">({skills.length})</span></h3>
        <div className="pill-group">
          {skills.map((s) => (
            <span key={s} className={`pill ${matched.includes(s) ? "pill-match" : "pill-neutral"}`}>
              {s}
            </span>
          ))}
          {skills.length === 0 && <p className="empty">No skills detected.</p>}
        </div>
      </div>

      {/* Matched skills */}
      {matched.length > 0 && (
        <div className="skill-section">
          <h3>✅ Matched Skills <span className="count">({matched.length})</span></h3>
          <div className="pill-group">
            {matched.map((s) => (
              <span key={s} className="pill pill-match">{s}</span>
            ))}
          </div>
        </div>
      )}

      {/* Missing skills */}
      {missing.length > 0 && (
        <div className="skill-section">
          <h3>❌ Skills Gap <span className="count">({missing.length})</span></h3>
          <p className="gap-hint">These skills appear in the job description but not your resume:</p>
          <div className="pill-group">
            {missing.map((s) => (
              <span key={s} className="pill pill-missing">{s}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
