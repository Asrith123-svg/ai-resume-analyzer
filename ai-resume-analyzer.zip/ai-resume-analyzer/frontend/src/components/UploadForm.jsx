import { useState, useRef } from "react";

export default function UploadForm({ onSubmit, loading }) {
  const [file, setFile] = useState(null);
  const [jobDescription, setJobDescription] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef();

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const dropped = e.dataTransfer.files[0];
    if (dropped?.type === "application/pdf") setFile(dropped);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!file) return;
    onSubmit({ file, jobDescription });
  };

  return (
    <form className="upload-form" onSubmit={handleSubmit}>
      {/* PDF Drop Zone */}
      <div
        className={`drop-zone ${dragOver ? "drag-over" : ""} ${file ? "has-file" : ""}`}
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => fileRef.current.click()}
      >
        <input
          ref={fileRef}
          type="file"
          accept=".pdf"
          hidden
          onChange={(e) => setFile(e.target.files[0])}
        />
        {file ? (
          <p className="file-name">📄 {file.name}</p>
        ) : (
          <>
            <span className="drop-icon">⬆️</span>
            <p>Drag & drop your resume PDF here, or click to browse</p>
          </>
        )}
      </div>

      {/* Job Description */}
      <div className="jd-section">
        <label htmlFor="jd">Job Description (optional — paste here for match scoring)</label>
        <textarea
          id="jd"
          rows={6}
          placeholder="Paste the job description here…"
          value={jobDescription}
          onChange={(e) => setJobDescription(e.target.value)}
        />
      </div>

      <button
        type="submit"
        className="analyze-btn"
        disabled={!file || loading}
      >
        {loading ? "Analyzing…" : "Analyze Resume"}
      </button>
    </form>
  );
}
